## Command-line interface

library("carat")

set.seed(20201, kind = "Mersenne-Twister", normal.kind = "Inversion",
         sample.kind = "Rejection")
if (interactive()) {
  HH.ui <- HuHuCAR.ui(path = getwd(), folder = "HuHuCAR")
}
T
sex
age
pills

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operations, that is PRESS the key of Enter for three times.
#(5) PRESS the key of ENTER
#(6) PRESS the key of ENTER
#(7) PRESS the key of ENTER

male
female

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operations, that is PRESS the key of Enter for two times.
# (10) PRESS the key of ENTER
# (11) PRESS the key of ENTER

0-30
30-50
>=51

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operations, that is PRESS the key of Enter for two times.
# (14) PRESS the key of ENTER
# (15) PRESS the key of ENTER

0
1-3
3-5
>=6

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operations, that is PRESS the key of Enter for two times.
# (20) PRESS the key of ENTER
# (21) PRESS the key of ENTER

1
2
1
2
1

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operation, that is PRESS the key of Enter.
# (27) PRESS the key of ENTER

0.85
female
30-50
>=6

## Do not run this part, or it'll be read by the function "readline".
## Please input nothing but do the following operation, that is PRESS the key of Enter.
#(32) PRESS the key of ENTER

HH.ui


## The step-by-step inputs or operations (PRESS the key of ENTER) are as follows:
# (1) T
# (2) sex
# (3) age
# (4) pills
# (5) PRESS the key of ENTER
# (6) PRESS the key of ENTER
# (7) PRESS the key of ENTER
# (8) male
# (9) female
# (10) PRESS the key of ENTER
# (11) 0-30
# (12) 30-50
# (13) >=51
# (14) PRESS the key of ENTER
# (15) PRESS the key of ENTER
# (16) 0
# (17) 1-3
# (18) 3-5
# (19) >=6
# (20) PRESS the key of ENTER
# (21) PRESS the key of ENTER
# (22) 1
# (23) 2
# (24) 1
# (25) 2
# (26) 1
# (27) PRESS the key of ENTER
# (28) 0.85
# (29) female
# (30) 30-50
# (31) >=6
# (32) PRESS the key of ENTER

